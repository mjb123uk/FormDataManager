<?php
require_once (dirname(dirname(__FILE__)) . '/fdmlayouts.class.php');
class FdmLayouts_mysql extends FdmLayouts {}