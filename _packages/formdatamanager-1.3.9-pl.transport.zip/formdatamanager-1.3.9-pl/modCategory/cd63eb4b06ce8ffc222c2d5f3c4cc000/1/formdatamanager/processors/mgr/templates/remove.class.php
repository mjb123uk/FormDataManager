<?php
/**
 * Remove a layout
 *
 * @package formdatamanager
 * @subpackage processors
 */
 
class FormDataManagerTemplateRemoveProcessor extends modObjectRemoveProcessor
{
    public $classKey = 'FdmLayouts';
	
}
return 'FormDataManagerTemplateRemoveProcessor';