Ext.onReady(function(){
	MODx.load({xtype:'mod-formdatamanager-page-viewdata'});
});

ModFormDataManager.page.Viewdata=function(config) {
	config = config || {};
	Ext.applyIf(config,{
		formpanel:'mod-formdatamanager-viewdatapanel'
		,components:[{
			xtype:'mod-formdatamanager-viewdatapanel'
			,renderTo:'mod-extra-formdatamanager'}
		]
		,buttons:[{
			text:_('formdatamanager_exit')
			,id:'formdatamanager-exit'
			,cls:'primary-button'
			,handler:function(){
				MODx.loadPage('home','namespace=formdatamanager');
			}
		},{
			text:_('formdatamanager_export')
			,id:'formdatamanager-export'
			,handler: function (btn, e) {
                if (! this.exportDataWindow) {
                    this.exportDataWindow = MODx.load({
                        xtype: 'formdatamanager-window-export-data'
                        ,formid: ModFormDataManager.config.formid
						,layoutid: ModFormDataManager.config.layoutid
                    });
                }
                this.exportDataWindow.show(e.target);
            }
			,scope: this
		}]
	});
	ModFormDataManager.page.Viewdata.superclass.constructor.call(this,config);
};
Ext.extend(ModFormDataManager.page.Viewdata,MODx.Component,{
    windows: {}
});
Ext.reg('mod-formdatamanager-page-viewdata',ModFormDataManager.page.Viewdata);

ModFormDataManager.window.ExportData = function (config) {
    config = config || {};
    config.id = Ext.id();

    Ext.applyIf(config, {
        title: _('formdatamanager_form.export')
        ,autoHeight: true
        ,closeAction: 'hide'
		,modal: true
        ,width: 540
        ,defaults: {
            border: false,
            autoHeight: true,
            bodyStyle: 'padding: 5px 8px 5px 5px;',
            layout: 'form',
            deferredRender: false,
            forceLayout: true
        }
        ,buttons: [{
            text: config.cancelBtnText || _('cancel')
            ,scope: this
            ,handler: function() { config.closeAction !== 'close' ? this.hide() : this.close(); }
        }, '-', {
            text: _('formdatamanager_export')
            ,cls: 'trigger-action primary-button'
			,scope: this
            ,handler: function (btn, e) {

				// hide export options window on export
				this.hide();
				
                 // Create dummy form to trick
                 // Ext Ajax request for force file download

                if (!Ext.fly('frmDummy')) {
                    var frm = document.createElement('form');
                    frm.id = 'frmDummy';
                    frm.formid = config.formid;
					frm.layoutid = config.layoutid;
                    frm.className = 'x-hidden';
                    document.body.appendChild(frm);
                }
                MODx.Ajax.request({
                    url: ModFormDataManager.config.connector_url
                    ,params: {
                        action: 'exportdata'
                        ,formid: config.formid
						,layoutid: config.layoutid
                        ,startDate: Ext.getCmp('startDate').getValue()
                        ,endDate: Ext.getCmp('endDate').getValue()
                    }
                    ,form: Ext.fly('frmDummy')
                    ,isUpload: true
                    /*
					,listeners: {
                        'success': { fn: function(r) {
                            //	
                        }, scope: this }
                    }
					*/
                });
            }
        }]
        ,fields: [{
            title: _('formdatamanager_export.daterange')
            ,layout: 'column'
            ,bodyCssClass: 'main-wrapper'
            ,autoHeight: true
            //,collapsible: true
            //,collapsed: true
            ,border: true
            ,hideMode: 'offsets'
            ,defaults: {
                layout: 'form'
                ,border: false
            }
            ,items: [{
                columnWidth: .5
                ,items: [{
                    xtype: 'datefield'
                    ,fieldLabel: _('formdatamanager_export.start_date')
                    ,name: 'start_date'
                    ,id: 'startDate'
                    ,grow: false
                    ,anchor: '100%'
                }]
            }, {
                columnWidth: .5
                ,items: [{
                    xtype: 'datefield'
                    ,fieldLabel: _('formdatamanager_export.end_date')
                    ,name: 'end_date'
                    ,id: 'endDate'
                    ,grow: false
                    ,anchor: '100%'
                }]
            }]
        }]
    });
    ModFormDataManager.window.ExportData.superclass.constructor.call(this, config);
};
Ext.extend(ModFormDataManager.window.ExportData, MODx.Window);
Ext.reg('formdatamanager-window-export-data', ModFormDataManager.window.ExportData);
