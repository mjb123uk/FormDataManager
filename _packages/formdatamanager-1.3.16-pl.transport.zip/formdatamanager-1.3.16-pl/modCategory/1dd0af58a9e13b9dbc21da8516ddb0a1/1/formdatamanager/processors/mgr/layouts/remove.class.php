<?php
/**
 * Remove a layout
 *
 * @package formdatamanager
 * @subpackage processors
 */
 
class FormDataManagerLayoutRemoveProcessor extends modObjectRemoveProcessor
{
    public $classKey = 'FdmLayouts';
	
}
return 'FormDataManagerLayoutRemoveProcessor';