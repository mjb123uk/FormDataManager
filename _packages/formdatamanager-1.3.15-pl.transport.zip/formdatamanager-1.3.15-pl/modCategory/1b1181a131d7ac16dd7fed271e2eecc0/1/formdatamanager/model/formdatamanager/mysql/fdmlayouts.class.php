<?php
require_once (dirname(__DIR__) . '/fdmlayouts.class.php');
class FdmLayouts_mysql extends FdmLayouts {}