<?php
/**
 * Remove a layout
 *
 * @package formdatamanager
 * @subpackage processors
 */
 
class FormDataManagerTableRemoveProcessor extends modObjectRemoveProcessor
{
    public $classKey = 'FdmLayouts';
	
}
return 'FormDataManagerTableRemoveProcessor';