<?php
class FdmLayouts extends xPDOSimpleObject {}